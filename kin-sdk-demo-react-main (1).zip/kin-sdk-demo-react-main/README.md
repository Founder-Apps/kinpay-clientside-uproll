# kin-sdk-demo-react

Demo of using the [kin-sdk](https://github.com/kin-sdk/kin-sdk) in a React app.

## Project setup

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn start
```

### Compiles and minifies for production

```
yarn build
```
